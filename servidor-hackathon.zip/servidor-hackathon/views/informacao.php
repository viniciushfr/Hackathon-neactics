<?php 
include_once 'templates/header.php';
?>

    <script>
        $(document).ready(function () {
            $.ajax({
                type: "POST",
                url: "../controllers/AtualizarDados.php",
                data: new FormData(this),
                contentType: false,
                processData: false,
                cache: false,
                success: function (response) {
                    response = JSON.parse(response);
                    $('#temperatura-ar').html(response.temperaturaAr + 'º');
                    $('#umidade-ar').html(response.umidadeAr + '%');
                    $('#temperatura-solo').html(response.temperaturaSolo + 'º');
                    $('#umidade-solo').html(response.umidadeSolo + '%');
                    $('#data').html(response.data);
                }
            });
            setInterval(function() {
                $.ajax({
                    type: "POST",
                    url: "../controllers/AtualizarDados.php",
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    cache: false,
                    success: function (response) {
                        response = JSON.parse(response);
                        $('#temperatura-ar').html(response.temperaturaAr + 'º');
                        $('#umidade-ar').html(response.umidadeAr + '%');
                        $('#temperatura-solo').html(response.temperaturaSolo + 'º');
                        $('#umidade-solo').html(response.umidadeSolo + '%');
                        $('#data').html(response.data);
                    }
                });
            }, 10000)
        });
    </script>
    
    <div class="container" style="padding-top: 15px">
        <form>
            <div class="form-group">
                <div class="row">
                    <h3 style="margin-top: 0px">Preset:</h3>
                    <select class="selectpicker" name="preset" id="preset" data-live-search="true" title="Selecione um preset">
                        <option value="Tomate" selected>Tomate</option>
                    </select>
                    <input type="submit" value="Salvar" class="btn btn-info">
                </div>
            </div>
        </form>
        
        <div class="well row">
            <h3 class="col-xs-9">Temperatura do Ar:</h3>
            <h3 class="col-xs-3"><p class="pull-right" id="temperatura-ar"></p></h3>
        </div>
        <div class="well row">
            <h3 class="col-xs-9">Umidade do Ar:</h3>
            <h3 class="col-xs-3"><p class="pull-right" id="umidade-ar"></p></h3>
        </div>
        <div class="well row">
            <h3 class="col-xs-9">Temperatura do Solo:</h3>
            <h3 class="col-xs-3"><p class="pull-right" id="temperatura-solo"></p></h3>
        </div>
        <div class="well row">
            <h3 class="col-xs-9">Umidade do Solo:</h3>
            <h3 class="col-xs-3"><p class="pull-right" id="umidade-solo"></p></h3>
        </div>
        <div class="row alert alert-info">
            <p class="col-xs-9"><strong>Última atualização: </strong></p>
            <p class="col-xs-3 pull-right" id="data"></p>
        </div>
    </div>
    
<?php 
include_once 'templates/footer.php';
?>