<?php
session_start();
if($_SESSION['logado']==true && isset($_SESSION['lembrar']) && $_SESSION['lembrar']==true){
    header("Location: ./index.php");
}
?>
<!DOCTYPE html>
<html lang="pt"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>

    <!-- Bootstrap core CSS -->
    <link href="../resources/css/bootstrap.min.css" rel="stylesheet">
    
    <script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>
  </head>

  <body>

    <script type="text/javascript">
        $(document).ready(function () {
            $("#form-logar").on('submit', function (e) {
                $('#logar-loading').css('display', 'inline');
                e.preventDefault();
                $.ajax({
                    type: "POST",
                    url: "../controllers/LoginController.php",
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    cache: false,
                    success: function (response) {
                        if (response == 'success') {
                            $("#mensagem").removeClass("alert-danger alert-warning");
                            $("#mensagem").addClass("alert alert-success");
                            $("#mensagem").html("Logado com sucesso!");
                            window.location.href = "./informacao.php";
                        }
                        else if (response == 'error') {
                            $("#mensagem").removeClass("alert-success alert-warning");
                            $("#mensagem").addClass("alert alert-danger");
                            $("#mensagem").html("Usuário ou senha incorretos.");
                            $('#logar-loading').css('display', 'none');
                        }
                        else if (response == 'empty') {
                            $("#mensagem").removeClass("alert-success alert-danger");
                            $("#mensagem").addClass("alert alert-warning");
                            $("#mensagem").html("Preencha todos os campos.");
                            $('#logar-loading').css('display', 'none');
                        }
                        else if(response.indexOf("Array")!==-1){
                            $("#mensagem").removeClass("alert-success alert-warning");
                            $("#mensagem").addClass("alert alert-danger");
                            $("#mensagem").html("Mude pelo menos um campo.");
                            $('#logar-loading').css('display', 'none');
                        }
                        else{
                            $("#mensagem").removeClass("alert-success alert-warning");
                            $("#mensagem").addClass("alert alert-danger");
                            $("#mensagem").html(response);
                            $('#logar-loading').css('display', 'none');
                        }
                    }
                });
                return false;
            });
        });
    </script>

    <div class="container">
        <div class="row vertical-offset-100" style="margin-top: 30px">
        	<div class="col-md-4 col-md-offset-4">
        		<div class="panel panel-default">
    			  	<div class="panel-heading">
    			    	<h3 class="panel-title">Entrar</h3>
    			    	<i id="logar-loading" class="fa fa-spinner fa-spin fa-pulse fa-lg" style="display: none"></i>
    			 	</div>
    			  	<div class="panel-body">
    			    	<form accept-charset="UTF-8" id="form-logar" role="form" method="post">
                            <fieldset>
        			    	  	<div class="form-group">
        			    		    <input class="form-control" placeholder="Login" name="login" value="admin" type="text" required>
        			    		</div>
        			    		<div class="form-group">
        			    			<input class="form-control" placeholder="Senha" name="senha" type="password" value="admin" required>
        			    		</div>
        			    		<div class="checkbox">
        			    	    	<label>
        			    	    		<input name="remember" type="checkbox" value="Lembrar"> Lembrar
        			    	    	</label>
        			    	    </div>
        			    		<input class="btn btn-lg btn-success btn-block" type="submit" value="Entrar">
        			    		<div id="mensagem" style="margin-top: 15px"></div>
        			    	</fieldset>
    			      	</form>
    			    </div>
    			</div>
    		</div>
    	</div>
    </div>
</body>
</html>