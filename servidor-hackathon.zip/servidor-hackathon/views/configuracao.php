<?php 
include_once 'templates/header.php';
?>
    
    <script type="text/javascript">
        $(document).ready(function () {
            $("#form-salvar").on('submit', function (e) {
                $('#salvar-loading').css('display', 'inline');
                e.preventDefault();
                $.ajax({
                    type: "POST",
                    url: "../controllers/ConfiguracoesController.php",
                    data: new FormData(this),
                    contentType: false,
                    processData: false,
                    cache: false,
                    success: function (response) {
                        if (response == 'success') {
                            $("#mensagem").removeClass("alert-danger alert-warning");
                            $("#mensagem").addClass("alert alert-success");
                            $("#mensagem").html("Configurações salvas!");
                        }
                        else if (response == 'error') {
                            $("#mensagem").removeClass("alert-success alert-warning");
                            $("#mensagem").addClass("alert alert-danger");
                            $("#mensagem").html("Houve algum erro.");
                            $('#salvar-loading').css('display', 'none');
                        }
                        else if (response == 'empty') {
                            $("#mensagem").removeClass("alert-success alert-danger");
                            $("#mensagem").addClass("alert alert-warning");
                            $("#mensagem").html("Preencha todos os campos.");
                            $('#salvar-loading').css('display', 'none');
                        }
                        else{
                            $("#mensagem").removeClass("alert-success alert-warning");
                            $("#mensagem").addClass("alert alert-danger");
                            $("#mensagem").html(response);
                            $('#salvar-loading').css('display', 'none');
                        }
                    }
                });
                return false;
            });
        });
    </script>
    
    <div class="container" style="padding-top: 15px">
        
        <form id="form-salvar" enctype="multipart/form-data" method="post" role="form">
            <div class="panel panel-default">
                <header class="panel-heading">
                    <h3>Configurações</h3>
                </header>
                <div class="panel-body">
                    <div class="form-group">
                        <label>Umidade do solo mínima</label>
                        <input type="number" name="capacidade-minima" step="any" value="<?=$capacidadeMinima?>" id="capacidade-minima" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Umidade do solo máxima</label>
                        <input type="number" name="capacidade-maxima" step="any" value="<?=$umidadeMaxima?>" id="capacidade-maxima" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Temperatura mínima</label>
                        <input type="number" name="temperatura-minima" step="any" value="<?=$temperaturaMinima?>" id="temperatura-minima" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Temperatura máxima</label>
                        <input type="number" name="temperatura-maxima" step="any" value="<?=$tempraturaMaxima?>" id="temperatura-maxima" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Irrigar a partir de</label>
                        <input type="time" name="tempo-inicial" step="any" value="<?=$tempoInicial?>" id="tempo-inicial" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Irrigar até</label>
                        <input type="time" name="tempo-final" step="any" value="<?=$tempoFinal?>" id="tempo-final" class="form-control">
                    </div>
                </div>
                <footer class="panel-footer">
                    <input type="submit" value="Salvar" class="btn btn-info">
                    <i id="salvar-loading" class="fa fa-spinner fa-spin fa-pulse fa-lg" style="display: none"></i>
                </footer>
            </div>
            <div id="mensagem" style="margin-top: 15px"></div>
        </form>
    </div>
    

<?php include_once 'templates/footer.php'?>