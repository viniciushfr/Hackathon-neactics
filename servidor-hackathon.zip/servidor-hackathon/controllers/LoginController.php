<?php
$login = $_POST['login'];
$senha = $_POST['senha'];

LoginController::logar($login, $senha);

class LoginController{
    public static function logar($login, $senha){
        if($senha=='admin' && $login=='admin'){
            session_start();
            $_SESSION['logado'] = true;
            $_SESSION['lembrar'] = true;
            echo 'success';
        }else{
            echo 'error';
        }
    }
}

?>