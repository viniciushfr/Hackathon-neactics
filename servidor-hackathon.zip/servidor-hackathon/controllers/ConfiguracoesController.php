<?php

$capacidadeMinima = $_POST['capacidade-minima'];
$capacidadeMaxima = $_POST['capacidade-maxima'];
$temperaturaMinima = $_POST['temperatura-minima'];
$temperaturaMaxima = $_POST['temperatura-maxima'];
$tempoInicial = $_POST['tempo-inicial'];
$tempoFinal = $_POST['tempo-final'];

$arquivo = end(file('../preset.txt'));

unlink('../presets/'.$arquivo.'.txt');

$file = fopen('../presets/'.$arquivo.'.txt', 'a');

fwrite($file, "nome=".$arquivo."\n");
fwrite($file, "capacidadeMinima=".$capacidadeMinima."\n");
fwrite($file, "capacidadeMaxima=".$capacidadeMaxima."\n");
fwrite($file, "horaInicial=".$tempoInicial."\n");
fwrite($file, "horaFinal=".$tempoFinal."\n");
fwrite($file, "temperaturaMinima=".$temperaturaMinima."\n");
fwrite($file, "temperaturaMaxima=".$temperaturaMaxima."\n");

fclose($file);

echo 'success';
?>