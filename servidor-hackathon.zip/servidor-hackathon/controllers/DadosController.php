<?php

$temperaturaAr = $_GET['temperaturaAr'];
$umidadeAr = $_GET['umidadeAr'];
$temperaturaSolo = $_GET['temperaturaSolo'];
$umidadeSolo = $_GET['umidadeSolo'];
$hoje = new DateTime();
$hoje->setTimezone(new DateTimeZone('America/Sao_Paulo'));

$arquivo = fopen('../dados-sensores.txt', 'a');
fwrite($arquivo, $temperaturaAr . ';' . $umidadeAr . ';' . $temperaturaSolo . ';' . $umidadeSolo . ';' . $hoje->format('d/m/Y H:i:s') . "\n");
fclose($arquivo);

echo 'Ok!';
?>