<?php

    $linha = end(file('../dados-sensores.txt'));
    list($temperaturaAr, $umidadeAr, $temperaturaSolo, $umidadeSolo, $data) = explode(";", $linha);
    $array = array('temperaturaAr'=>$temperaturaAr,'umidadeAr'=>$umidadeAr,'temperaturaSolo'=>$temperaturaSolo,'umidadeSolo'=>$umidadeSolo,'data'=>$data);
    $json = json_encode($array);
    echo $json;

?>