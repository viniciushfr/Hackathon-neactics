<?php

class Formatter{
    public static function transform($data){
        return substr($data,0,10). "T" . substr($data,11) . ".000";
    }
    
    public static function formatDateTime($data){
        $date = new DateTime($data);
        return date_format($date, 'd/m/Y H:i');
    }
    
    public static function formatDate($data){
        $date = new DateTime($data);
        return date_format($date, 'd/m/Y');
    }
    
    public static function formatCurrency($valor){
        return money_format('%.2n', $valor);
    }
}

?>