var id;

function passarId(idP){
    id = idP;
}

$(document).ready(function () {
    $("#form-salvar").on('submit', function (e) {
        $('#salvar-loading').css('display', 'inline');
        e.preventDefault();
        var controller = $("#form-salvar").attr("controller");
        $.ajax({
            type: "POST",
            url: "../controllers/" + controller,
            data: new FormData(this),
            contentType: false,
            processData: false,
            cache: false,
            success: function (response) {
                if (response == 'success') {
                    $("#mensagem").removeClass("alert-danger alert-warning");
                    $("#mensagem").addClass("alert alert-success");
                    $("#mensagem").html("Salvo com sucesso!");
                    location.reload();
                }
                else if (response == 'error') {
                    $("#mensagem").removeClass("alert-success alert-warning");
                    $("#mensagem").addClass("alert alert-danger");
                    $("#mensagem").html("Houve um erro ao adicionar no banco.");
                    $('#salvar-loading').css('display', 'none');
                }
                else if (response == 'empty') {
                    $("#mensagem").removeClass("alert-success alert-danger");
                    $("#mensagem").addClass("alert alert-warning");
                    $("#mensagem").html("Preencha todos os campos.");
                    $('#salvar-loading').css('display', 'none');
                }
                else if(response.indexOf("Array")!==-1){
                    $("#mensagem").removeClass("alert-success alert-warning");
                    $("#mensagem").addClass("alert alert-danger");
                    $("#mensagem").html("Mude pelo menos um campo.");
                    $('#salvar-loading').css('display', 'none');
                }
                else{
                    $("#mensagem").removeClass("alert-success alert-warning");
                    $("#mensagem").addClass("alert alert-danger");
                    $("#mensagem").html(response);
                    $('#salvar-loading').css('display', 'none');
                }
            },
            error: function(e){
                console.log(e);
            }
        });
        return false;
    });
    
    $("#btn-deletar").click(function () {
        $('#deletar-loading').css('display', 'inline');
        var controller = $("#form-salvar").attr("controller");
        $.ajax({
            type: "POST",
            url: "../controllers/" + controller,
            data: {id: id},
            success: function (response) {
                if (response == 'success') {
                    location.reload();
                }
                else if(response == 'error'){
                    $("#mensagem-confirmacao").addClass("alert alert-danger");
                    $("#mensagem-confirmacao").html("Houve um erro ao excluir do banco.");
                    $('#deletar-loading').css('display', 'none');
                }else{
                    $("#mensagem-confirmacao").addClass("alert alert-danger");
                    $("#mensagem-confirmacao").html(response);
                    $('#deletar-loading').css('display', 'none');
                }
            }
        });
        return false;
    });
});